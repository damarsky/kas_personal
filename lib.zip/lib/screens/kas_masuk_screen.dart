import 'package:flutter/material.dart';
import 'package:kas_personal/models/kas.dart';
import 'package:kas_personal/widgets/kas_item.dart';

class KasMasukScreen extends StatefulWidget {
  const KasMasukScreen({super.key});

  @override
  State<KasMasukScreen> createState() => _KasMasukScreenState();
}

class _KasMasukScreenState extends State<KasMasukScreen> {
  var items = <Kas>[
    Kas.masuk(
        keterangan: 'Dikasih tante', nominal: 2000, dateTime: DateTime.now()),
    Kas.masuk(
        keterangan: 'Dikasih Om', nominal: 50000, dateTime: DateTime.now()),
    Kas.masuk(
        keterangan: 'Maling Kotak Amal',
        nominal: 100000,
        dateTime: DateTime.now()),
  ];

  void baru() async {
    await showDialog(
      context: context,
      builder: (context) {
        return const Dialog(
          child: BaruDialog(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kas Masuk'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: baru,
        child: const Icon(Icons.add),
      ),
      body: ListView.separated(
        itemCount: items.length,
        separatorBuilder: (context, index) => Divider(
          height: 0,
          color: Colors.green.shade200,
        ),
        itemBuilder: (context, index) {
          var kas = items[index];
          return KasItem(
            kas: kas,
            onTap: () => onItemTap(kas),
          );
        },
      ),
    );
  }

  onItemTap(Kas kas) {}
}

class BaruDialog extends StatefulWidget {
  const BaruDialog({super.key});

  @override
  State<BaruDialog> createState() => _BaruDialogState();
}

class _BaruDialogState extends State<BaruDialog> {
  final nominalController = TextEditingController(text: '');
  final keteranganController = TextEditingController(text: '');

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Buat Kas Masuk',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          TextField(
            controller: nominalController,
            decoration: const InputDecoration(
              labelText: 'nominal',
              filled: true,
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(
            height: 10,
          ),
          TextField(
            controller: keteranganController,
            decoration: const InputDecoration(
              labelText: 'Keterangan',
              filled: true,
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              child: const Text('Simpan'),
            ),
          ),
        ],
      ),
    );
  }
}
