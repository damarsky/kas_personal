import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:kas_personal/widgets/creator.info.dart';
import 'package:kas_personal/widgets/custom_icon_button.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void onKasMasukTap() => context.goNamed('kas_masuk');

  void onInfoTap() async {
    await showDialog(
      context: context,
      builder: (context) {
        return const Dialog(
          child: CreatorInfo(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kas Personal Valent'),
      ),
      body: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Flexible(
                  fit: FlexFit.tight,
                  child: CustomIconButton(
                    backgroundColor: const Color.fromARGB(255, 7, 238, 255),
                    icon: Icons.credit_card,
                    text: 'kas_masuk',
                    onTap: onKasMasukTap,
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                Flexible(
                  fit: FlexFit.tight,
                  child: CustomIconButton(
                    backgroundColor: const Color.fromARGB(255, 7, 238, 255),
                    icon: Icons.receipt,
                    text: 'Kas Keluar',
                    onTap: () {},
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            CustomIconButton(
              backgroundColor: const Color.fromARGB(255, 7, 238, 255),
              icon: Icons.info,
              text: 'Tentang Pembuat',
              onTap: onInfoTap,
            ),
          ],
        ),
      ),
    );
  }
}
